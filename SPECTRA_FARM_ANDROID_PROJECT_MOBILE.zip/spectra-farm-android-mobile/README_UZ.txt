SPECTRA FARM — Android APK tayyorlash

Ushbu loyiha siz yuborgan SPECTRA FARM telefon ko‘rinishiga moslangan. Mobil ekran, pastki menyu va Android safe-area chetlari hisobga olingan. React ilovasini Android APK ga aylantirish uchun tayyor.

KERAK BO'LADI:
- Node.js (LTS)
- Android Studio va Android SDK
- JDK 17 yoki 21

APK YASASH:
1. Ushbu papkani kompyuterga oching.
2. Terminal/CMD da shu papkaga kiring.
3. Quyidagi buyruqlarni ketma-ket bajaring:

   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android

4. Android Studio ochilgach, Gradle sync tugashini kuting.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
6. APK odatda android/app/build/outputs/apk/debug/app-debug.apk manzilida bo'ladi.

MUHIM:
- Ushbu muhitda Android SDK/Gradle mavjud bo'lmagani uchun tayyor APK faylini bu yerning o'zida kompilyatsiya qilib bo'lmadi. ZIP — APK yig'ish uchun tayyor loyiha.
- Dasturdagi AI javoblari hozir demo/maket javoblaridir; haqiqiy AI serveriga ulanmagan.
- Dala ko'rsatkichlari va IoT sensor ma'lumotlari namunaviy. Haqiqiy sensor/klapanlarni boshqarish uchun qurilma API/backend integratsiyasi kerak.
