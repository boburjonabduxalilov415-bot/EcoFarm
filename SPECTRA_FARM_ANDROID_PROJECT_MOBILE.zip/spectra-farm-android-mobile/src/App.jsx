import React, { useState, useEffect } from 'react';
import {
  Sprout,
  Sun,
  CloudRain,
  Droplets,
  Wind,
  ShieldAlert,
  Plus,
  Send,
  Camera,
  Layers,
  Activity,
  Sliders,
  Globe,
  Wifi,
  CheckCircle2,
  ChevronRight,
  Leaf,
  MapPin,
  RefreshCw,
  Sparkles,
  Zap,
  Radio,
  Cpu,
  ToggleLeft,
  ToggleRight,
  X,
  Compass,
  LayoutDashboard
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [lang, setLang] = useState('uz');
  
  // Fields State
  const [fields, setFields] = useState([
    {
      id: 1,
      name: "Shimoliy Bug'doy Maydoni",
      area: "14.5 ga",
      crop: "Kuzgi Bug'doy",
      moisture: 72,
      ph: 6.8,
      minerals: "N90 P60 K40",
      ndvi: 0.88,
      status: "A'lo",
      irrigation: false,
      lastUpdated: "10 daqiqa oldin",
      gradient: "from-emerald-500/20 via-teal-500/10 to-transparent",
      glowColor: "#00FF9D"
    },
    {
      id: 2,
      name: "Janubiy Paxta Dalasi",
      area: "22.0 ga",
      crop: "Paxta (Buxoro-6)",
      moisture: 44,
      ph: 7.2,
      minerals: "N60 P45 K30",
      ndvi: 0.62,
      status: "Diqqat talab",
      irrigation: true,
      lastUpdated: "5 daqiqa oldin",
      gradient: "from-amber-500/20 via-orange-500/10 to-transparent",
      glowColor: "#FFB800"
    },
    {
      id: 3,
      name: "Issiqxona #4 (Pomidor)",
      area: "3.2 ga",
      crop: "Pomidor (Yuksalish)",
      moisture: 85,
      ph: 6.5,
      minerals: "N110 P80 K90",
      ndvi: 0.94,
      status: "Optimal",
      irrigation: true,
      lastUpdated: "Hozirgina",
      gradient: "from-cyan-500/20 via-blue-500/10 to-transparent",
      glowColor: "#00E5FF"
    },
    {
      id: 4,
      name: "G'arbiy Makkajo'xori",
      area: "18.8 ga",
      crop: "Makkajo'xori",
      moisture: 68,
      ph: 6.9,
      minerals: "N100 P50 K50",
      ndvi: 0.78,
      status: "Yaxshi",
      irrigation: false,
      lastUpdated: "25 daqiqa oldin",
      gradient: "from-fuchsia-500/20 via-pink-500/10 to-transparent",
      glowColor: "#FF2A85"
    }
  ]);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newField, setNewField] = useState({ name: '', area: '', crop: '' });

  // AI Assistant Chat State
  const [chatMessages, setChatMessages] = useState([
    {
      sender: 'ai',
      text: "Salom! Men Spectra Liquid AI yordamchisiman. Barglar diagnostikasi, tuproq tahlili va hosildorlikni oshirish bo'yicha yordam berishga tayyorman ✨",
      time: '14:30'
    }
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [imagePreview, setImagePreview] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Settings & IoT State
  const [autoIrrigation, setAutoIrrigation] = useState(true);
  const [aiAlerts, setAiAlerts] = useState(true);
  
  const [sensors, setSensors] = useState([
    { name: "Dala Sensori #1 (LoRaWAN)", status: "Ulangan", battery: 96, signal: "A'lo (-72dBm)" },
    { name: "Avtomatik Sug'orish Klapani A-2", status: "Faol", battery: 88, signal: "Yaxshi (-85dBm)" },
    { name: "Spectra AI Meteostansiya", status: "Ulangan", battery: 100, signal: "A'lo (-65dBm)" },
    { name: "Spektral Dron Ska-04", status: "Kutish rejimida", battery: 74, signal: "Kutmoqda" }
  ]);

  // Toggle Irrigation for a Field
  const toggleIrrigation = (id) => {
    setFields(fields.map(f => f.id === id ? { ...f, irrigation: !f.irrigation } : f));
  };

  // Add Field Handler
  const handleAddField = (e) => {
    e.preventDefault();
    if (!newField.name || !newField.area) return;

    const created = {
      id: Date.now(),
      name: newField.name,
      area: `${newField.area} ga`,
      crop: newField.crop || 'Belgilanmagan',
      moisture: 65,
      ph: 6.7,
      minerals: "N80 P50 K40",
      ndvi: 0.75,
      status: "Yangi",
      irrigation: false,
      lastUpdated: "Hozirgina",
      gradient: "from-emerald-500/20 via-teal-500/10 to-transparent",
      glowColor: "#00FF9D"
    };

    setFields([created, ...fields]);
    setNewField({ name: '', area: '', crop: '' });
    setIsAddModalOpen(false);
  };

  // Send AI Message
  const handleSendMessage = (e) => {
    e?.preventDefault();
    if (!inputMsg.trim() && !imagePreview) return;

    const userText = inputMsg;
    const hasImage = !!imagePreview;

    const newMsg = {
      sender: 'user',
      text: userText,
      image: imagePreview,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages((prev) => [...prev, newMsg]);
    setInputMsg('');
    setImagePreview(null);
    setIsAnalyzing(true);

    setTimeout(() => {
      let replyText = "Spektral tahlil yakunlandi: ";

      if (hasImage) {
        replyText += "Barg tasvirida erta zang (Puccinia stripiformis) alomatlari 89% aniqlik bilan topildi. Mis saqlovchi bio-fungitsid purkash va namlikni 10% ga pasaytirish maslahat beriladi.";
      } else if (userText.toLowerCase().includes('barg') || userText.toLowerCase().includes('sarg')) {
        replyText += "Barglarning sarg'ayishi ko'pincha Azot (N) yetishmovchiligi yoki ildiz bo'g'ilishidan kelib chiqadi. Tuproq pH va mineral balansini tekshirishni tavsiya etaman.";
      } else if (userText.toLowerCase().includes('o\'g\'it') || userText.toLowerCase().includes('ogit')) {
        replyText += "Hozirgi vegetatsiya davrida gektariga 110 kg karbamid va 40 kg kaliy sulfat berish foto-sintez darajasini 22% ga oshiradi.";
      } else {
        replyText += "Spectra IoT datchiklaridan olingan ma'lumotlarga ko'ra, ekinlarning umumiy biosaviyasi barqaror darajada.";
      }

      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: replyText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsAnalyzing(false);
    }, 1300);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-[#060911] text-slate-100 font-sans relative overflow-x-hidden pb-28">
      
      {/* AMBIENT LIQUID GLASS GLOW ORBS */}
      <div className="fixed top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-gradient-to-br from-emerald-600/25 via-teal-500/10 to-transparent blur-[120px] pointer-events-none animate-pulse" />
      <div className="fixed bottom-[-10%] right-[-5%] w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-cyan-600/20 via-blue-600/15 to-transparent blur-[140px] pointer-events-none" />
      <div className="fixed top-[35%] right-[10%] w-[400px] h-[400px] rounded-full bg-gradient-to-br from-fuchsia-600/15 via-purple-600/10 to-transparent blur-[130px] pointer-events-none" />

      {/* TOP COMPACT HEADER */}
      <header className="sticky top-0 z-40 bg-slate-950/40 backdrop-blur-xl border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.5)] px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          
          {/* Logo & Branding */}
          <div className="flex items-center gap-3">
            <div className="relative group">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-400 via-teal-300 to-cyan-400 p-[1px] shadow-[0_0_20px_rgba(0,255,157,0.4)]">
                <div className="w-full h-full bg-slate-950/80 backdrop-blur-md rounded-2xl flex items-center justify-center">
                  <Sprout className="w-5 h-5 text-[#00FF9D]" />
                </div>
              </div>
              <div className="absolute inset-0 rounded-2xl bg-[#00FF9D] blur-md opacity-30 group-hover:opacity-70 transition-opacity" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-wider bg-gradient-to-r from-[#00FF9D] via-[#00E5FF] to-teal-200 bg-clip-text text-transparent drop-shadow-[0_2px_10px_rgba(0,255,157,0.3)]">
                SPECTRA FARM
              </h1>
              <p className="text-[10px] text-emerald-400/90 font-medium tracking-wide flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FF9D] animate-ping" />
                Agro AI Monitoring
              </p>
            </div>
          </div>

          {/* Header Quick Pill */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/15 backdrop-blur-md text-xs">
            <Sun className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-slate-200">+28°C</span>
            <span className="hidden sm:inline text-slate-400 text-[10px]">| Tashkent</span>
          </div>

        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="max-w-7xl mx-auto px-4 py-6">

        {/* TAB 1: DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-fadeIn">
            
            {/* Glowing Smart Alert Card */}
            <div className="relative group overflow-hidden rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-transparent p-[1px] backdrop-blur-xl border border-amber-500/30 shadow-[0_8px_32px_0_rgba(255,184,0,0.1)]">
              <div className="bg-slate-950/70 backdrop-blur-xl rounded-2xl p-4 flex items-start gap-4">
                <div className="p-3 bg-amber-500/20 text-amber-300 rounded-xl border border-amber-500/40 shadow-[0_0_15px_rgba(255,184,0,0.3)]">
                  <ShieldAlert className="w-6 h-6 animate-pulse" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                      Tezkor Agrotexnik Bildirishnoma
                      <span className="bg-amber-500/20 text-amber-200 text-[10px] px-2 py-0.5 rounded-full border border-amber-500/40">Kritik</span>
                    </h3>
                    <span className="text-[10px] text-slate-400">10 daqiqa oldin</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Janubiy Paxta Dalasida tuproq namligi 44% ga tushdi. Avtomatik sug'orish klapani A-2 soat 18:00 da ishga tushiriladi.
                  </p>
                </div>
              </div>
            </div>

            {/* Floating Glass Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Stat 1 */}
              <div className="relative rounded-2xl bg-white/[0.04] backdrop-blur-xl p-5 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:border-[#00FF9D]/40 transition-all duration-300 group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">Tuproq Namligi</span>
                  <div className="p-2.5 rounded-xl bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/30 shadow-[0_0_10px_rgba(0,229,255,0.2)]">
                    <Droplets className="w-5 h-5" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-slate-100 drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">68%</span>
                    <span className="text-xs font-bold text-[#00FF9D]">Optimal (60-80%)</span>
                  </div>
                  <div className="w-full bg-slate-900/80 rounded-full h-2.5 mt-3 p-0.5 border border-white/10 overflow-hidden">
                    <div className="bg-gradient-to-r from-[#00E5FF] to-[#00FF9D] h-full rounded-full shadow-[0_0_12px_rgba(0,255,157,0.8)]" style={{ width: '68%' }} />
                  </div>
                </div>
              </div>

              {/* Stat 2 */}
              <div className="relative rounded-2xl bg-white/[0.04] backdrop-blur-xl p-5 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:border-emerald-400/40 transition-all duration-300 group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">NDVI Salomatlik</span>
                  <div className="p-2.5 rounded-xl bg-[#00FF9D]/10 text-[#00FF9D] border border-[#00FF9D]/30 shadow-[0_0_10px_rgba(0,255,157,0.2)]">
                    <Leaf className="w-5 h-5" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-slate-100 drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">0.88</span>
                    <span className="text-xs font-bold text-[#00FF9D]">A'lo Biosaviya</span>
                  </div>
                  <div className="w-full bg-slate-900/80 rounded-full h-2.5 mt-3 p-0.5 border border-white/10 overflow-hidden">
                    <div className="bg-gradient-to-r from-emerald-500 to-[#00FF9D] h-full rounded-full shadow-[0_0_12px_rgba(0,255,157,0.8)]" style={{ width: '88%' }} />
                  </div>
                </div>
              </div>

              {/* Stat 3 */}
              <div className="relative rounded-2xl bg-white/[0.04] backdrop-blur-xl p-5 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:border-amber-400/40 transition-all duration-300 group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">Mineral Balansi (pH)</span>
                  <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 shadow-[0_0_10px_rgba(255,184,0,0.2)]">
                    <Zap className="w-5 h-5" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-slate-100 drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">6.8 pH</span>
                    <span className="text-xs text-slate-400">N90 P60 K40</span>
                  </div>
                  <div className="w-full bg-slate-900/80 rounded-full h-2.5 mt-3 p-0.5 border border-white/10 overflow-hidden">
                    <div className="bg-gradient-to-r from-amber-400 to-yellow-300 h-full rounded-full shadow-[0_0_12px_rgba(255,184,0,0.8)]" style={{ width: '74%' }} />
                  </div>
                </div>
              </div>

              {/* Stat 4 */}
              <div className="relative rounded-2xl bg-white/[0.04] backdrop-blur-xl p-5 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:border-cyan-400/40 transition-all duration-300 group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">IoT Tarmog'i</span>
                  <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-[0_0_10px_rgba(0,229,255,0.2)]">
                    <Radio className="w-5 h-5" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-slate-100 drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">4 / 4</span>
                    <span className="text-xs font-bold text-[#00FF9D]">100% Onlayn</span>
                  </div>
                  <p className="text-[11px] text-[#00FF9D] mt-2 flex items-center gap-1 font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Barcha datchiklar faol
                  </p>
                </div>
              </div>

            </div>

            {/* Field Grid Overview */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-extrabold text-slate-100 flex items-center gap-2 tracking-wide">
                  <Layers className="w-5 h-5 text-[#00FF9D]" />
                  Maydonlar Holati & Spektral Tahlil
                </h2>
                <button 
                  onClick={() => setActiveTab('fields')}
                  className="text-xs text-[#00FF9D] hover:underline font-bold flex items-center gap-1"
                >
                  Barchasini ko'rish <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {fields.map((f) => (
                  <div 
                    key={f.id}
                    className="relative rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 hover:border-white/25 p-4 transition-all duration-300 shadow-[0_8px_32px_0_rgba(0,0,0,0.25)] overflow-hidden group"
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${f.gradient} opacity-40 pointer-events-none`} />

                    <div className="relative z-10 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-extrabold text-slate-100 text-sm group-hover:text-[#00FF9D] transition-colors">
                            {f.name}
                          </h4>
                          <p className="text-xs text-slate-400">{f.crop} • {f.area}</p>
                        </div>
                        <span 
                          className="text-[10px] font-bold px-2.5 py-0.5 rounded-full border backdrop-blur-md"
                          style={{ 
                            color: f.glowColor, 
                            borderColor: `${f.glowColor}50`, 
                            backgroundColor: `${f.glowColor}15` 
                          }}
                        >
                          {f.status}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-xs pt-1">
                        <div className="bg-slate-950/60 p-2 rounded-xl border border-white/10 text-center">
                          <span className="text-[9px] text-slate-400 block">Namlik</span>
                          <span className="font-bold text-[#00E5FF]">{f.moisture}%</span>
                        </div>
                        <div className="bg-slate-950/60 p-2 rounded-xl border border-white/10 text-center">
                          <span className="text-[9px] text-slate-400 block">NDVI</span>
                          <span className="font-bold text-[#00FF9D]">{f.ndvi}</span>
                        </div>
                        <div className="bg-slate-950/60 p-2 rounded-xl border border-white/10 text-center">
                          <span className="text-[9px] text-slate-400 block">pH</span>
                          <span className="font-bold text-amber-300">{f.ph}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: FIELDS MONITORING */}
        {activeTab === 'fields' && (
          <div className="space-y-6 animate-fadeIn">
            
            {/* Header Actions */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              <div>
                <h2 className="text-xl font-black text-slate-100 flex items-center gap-2">
                  <Layers className="w-6 h-6 text-[#00FF9D]" />
                  Ekin Maydonlari Monitoringi
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Dala kesimida sug'orish klapanlari va spektral datchiklarni boshqarish
                </p>
              </div>

              <button
                onClick={() => setIsAddModalOpen(true)}
                className="bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs px-5 py-3 rounded-xl shadow-[0_0_25px_rgba(0,255,157,0.4)] flex items-center gap-2 transition-all duration-300 transform active:scale-95"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Yangi Dala Qo'shish</span>
              </button>
            </div>

            {/* Grid of Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {fields.map((field) => (
                <div 
                  key={field.id} 
                  className="relative rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 hover:border-[#00FF9D]/40 transition-all duration-300 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] overflow-hidden group"
                >
                  <div className={`h-24 bg-gradient-to-r ${field.gradient} p-4 flex justify-between items-start relative`}>
                    <span className="bg-slate-950/80 backdrop-blur-md text-[#00FF9D] text-[10px] font-extrabold px-3 py-1 rounded-full border border-[#00FF9D]/30 shadow-md">
                      {field.crop}
                    </span>
                    <span className="text-xs font-bold text-white bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10">
                      {field.area}
                    </span>
                  </div>

                  <div className="p-5 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-base font-extrabold text-slate-100 group-hover:text-[#00FF9D] transition-colors">
                          {field.name}
                        </h3>
                        <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#00FF9D]" /> Yangilanish: {field.lastUpdated}
                        </p>
                      </div>
                      <span 
                        className="text-xs font-bold px-3 py-1 rounded-xl border backdrop-blur-md"
                        style={{ 
                          color: field.glowColor, 
                          borderColor: `${field.glowColor}50`, 
                          backgroundColor: `${field.glowColor}15` 
                        }}
                      >
                        {field.status}
                      </span>
                    </div>

                    {/* Sensor Metrics Grid */}
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-slate-950/60 p-3 rounded-xl border border-white/10 text-center">
                        <span className="text-[10px] text-slate-400 block mb-0.5">Namlik</span>
                        <span className="text-base font-black text-[#00E5FF]">{field.moisture}%</span>
                      </div>
                      <div className="bg-slate-950/60 p-3 rounded-xl border border-white/10 text-center">
                        <span className="text-[10px] text-slate-400 block mb-0.5">NDVI</span>
                        <span className="text-base font-black text-[#00FF9D]">{field.ndvi}</span>
                      </div>
                      <div className="bg-slate-950/60 p-3 rounded-xl border border-white/10 text-center">
                        <span className="text-[10px] text-slate-400 block mb-0.5">Mineral (pH)</span>
                        <span className="text-base font-black text-amber-300">{field.ph}</span>
                      </div>
                    </div>

                    {/* Irrigation Switch */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/50 border border-white/10 text-xs">
                      <span className="text-slate-300 font-semibold flex items-center gap-2">
                        <Droplets className="w-4 h-4 text-[#00E5FF]" /> Sug'orish Tizimi:
                      </span>
                      <button
                        onClick={() => toggleIrrigation(field.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-extrabold transition-all ${
                          field.irrigation
                            ? 'bg-emerald-500/20 text-[#00FF9D] border border-[#00FF9D]/50 shadow-[0_0_12px_rgba(0,255,157,0.3)]'
                            : 'bg-slate-800/80 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {field.irrigation ? <ToggleRight className="w-4 h-4 text-[#00FF9D]" /> : <ToggleLeft className="w-4 h-4" />}
                        <span>{field.irrigation ? 'FAOL' : 'FAOL EMAS'}</span>
                      </button>
                    </div>

                  </div>
                </div>
              ))}
            </div>

            {/* ADD FIELD MODAL */}
            {isAddModalOpen && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
                <div className="relative rounded-2xl bg-slate-950 border border-white/20 w-full max-w-md p-6 space-y-4 shadow-[0_0_50px_rgba(0,255,157,0.2)]">
                  <div className="flex justify-between items-center border-b border-white/10 pb-3">
                    <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                      <Plus className="w-5 h-5 text-[#00FF9D]" /> Yangi Dala Qo'shish
                    </h3>
                    <button 
                      onClick={() => setIsAddModalOpen(false)}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleAddField} className="space-y-4 text-xs">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1.5">Dala Nomi</label>
                      <input 
                        type="text" 
                        required
                        placeholder="Masalan: Sharqiy Olmalik Dala"
                        value={newField.name}
                        onChange={(e) => setNewField({...newField, name: e.target.value})}
                        className="w-full bg-white/[0.05] border border-white/15 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:border-[#00FF9D] transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-semibold mb-1.5">Maydoni (gektarda)</label>
                      <input 
                        type="number" 
                        step="0.1"
                        required
                        placeholder="Masalan: 12.5"
                        value={newField.area}
                        onChange={(e) => setNewField({...newField, area: e.target.value})}
                        className="w-full bg-white/[0.05] border border-white/15 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:border-[#00FF9D] transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-semibold mb-1.5">Ekin Turi</label>
                      <input 
                        type="text" 
                        placeholder="Masalan: Bug'doy, Paxta, Pomidor"
                        value={newField.crop}
                        onChange={(e) => setNewField({...newField, crop: e.target.value})}
                        className="w-full bg-white/[0.05] border border-white/15 rounded-xl px-4 py-3 text-slate-100 focus:outline-none focus:border-[#00FF9D] transition-colors"
                      />
                    </div>

                    <div className="pt-3 flex justify-end gap-3">
                      <button 
                        type="button"
                        onClick={() => setIsAddModalOpen(false)}
                        className="px-4 py-2.5 rounded-xl bg-white/10 text-slate-300 hover:bg-white/15 font-bold"
                      >
                        Bekor qilish
                      </button>
                      <button 
                        type="submit"
                        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black shadow-[0_0_20px_rgba(0,255,157,0.4)] hover:opacity-90"
                      >
                        Saqlash
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB 3: AGRO AI ASSISTANT */}
        {activeTab === 'ai' && (
          <div className="space-y-4 max-w-4xl mx-auto animate-fadeIn">
            
            {/* Header Banner */}
            <div className="rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 p-5 flex items-center gap-4 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              <div className="p-3 bg-gradient-to-tr from-emerald-400 via-teal-300 to-cyan-400 rounded-xl text-slate-950 shadow-[0_0_20px_rgba(0,255,157,0.4)]">
                <Sparkles className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h2 className="text-base font-extrabold text-slate-100">Spectra Liquid Agro AI</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Neuron-tarmoq va spektral kameralar orqali barg kasalliklari diagnostikasi va tavsiyalar
                </p>
              </div>
            </div>

            {/* Quick Prompt Chips */}
            <div className="flex flex-wrap gap-2">
              {[
                "Barg sarg'ayishi sabablari",
                "Bug'doy uchun o'g'it grafigi",
                "Tuproq pH balansini to'g'rilash",
                "Tomchilab sug'orish me'yori"
              ].map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => setInputMsg(chip)}
                  className="bg-white/[0.05] hover:bg-emerald-500/20 border border-white/10 hover:border-[#00FF9D]/40 text-[#00FF9D] text-xs px-3.5 py-2 rounded-full transition-all duration-300 backdrop-blur-md"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Chat Box Container */}
            <div className="rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 flex flex-col h-[480px] overflow-hidden shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              
              {/* Chat Messages */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-semibold rounded-br-none shadow-[0_0_15px_rgba(0,255,157,0.3)]'
                          : 'bg-slate-950/80 border border-white/10 text-slate-200 rounded-bl-none shadow-md backdrop-blur-md'
                      }`}
                    >
                      {msg.image && (
                        <img 
                          src={msg.image} 
                          alt="Uploaded leaf" 
                          className="w-52 h-36 object-cover rounded-xl mb-3 border border-white/20 shadow-md" 
                        />
                      )}
                      <p>{msg.text}</p>
                    </div>
                    <span className="text-[10px] text-slate-500 mt-1 px-1">{msg.time}</span>
                  </div>
                ))}

                {isAnalyzing && (
                  <div className="flex items-center gap-2 text-xs text-[#00FF9D] bg-slate-950/80 p-3 rounded-xl border border-[#00FF9D]/30 w-fit backdrop-blur-md">
                    <RefreshCw className="w-4 h-4 animate-spin text-[#00FF9D]" />
                    <span>Spektral neyrotarmoq tasvirni tahlil qilmoqda...</span>
                  </div>
                )}
              </div>

              {/* Chat Input Bar */}
              <form onSubmit={handleSendMessage} className="p-3 bg-slate-950/80 backdrop-blur-xl border-t border-white/10 flex items-center gap-3">
                
                <label className="p-3 text-slate-300 hover:text-[#00FF9D] bg-white/[0.05] border border-white/10 hover:border-[#00FF9D]/40 rounded-xl cursor-pointer transition-all">
                  <Camera className="w-4 h-4" />
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>

                <input
                  type="text"
                  placeholder="Barg kasalligi yoki o'g'itlash haqida so'rang..."
                  value={inputMsg}
                  onChange={(e) => setInputMsg(e.target.value)}
                  className="flex-1 bg-white/[0.05] border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-100 focus:outline-none focus:border-[#00FF9D] transition-colors"
                />

                <button
                  type="submit"
                  disabled={!inputMsg.trim() && !imagePreview}
                  className="p-3 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 disabled:opacity-40 text-slate-950 font-black rounded-xl transition-all shadow-[0_0_20px_rgba(0,255,157,0.3)]"
                >
                  <Send className="w-4 h-4 stroke-[2.5]" />
                </button>
              </form>

            </div>

          </div>
        )}

        {/* TAB 4: SETTINGS & IOT */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
            
            {/* Header */}
            <div className="rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              <h2 className="text-lg font-black text-slate-100 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-[#00FF9D]" />
                IoT Datchiklar & Tizim Sozlamalari
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                LoRaWAN / NBIoT datchiklar holati va avtomatlashtirish qoidalari
              </p>
            </div>

            {/* Sensors List */}
            <div className="rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 p-5 space-y-4 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              <h3 className="text-sm font-extrabold text-slate-200 flex items-center gap-2">
                <Wifi className="w-4 h-4 text-[#00E5FF]" />
                Ulangan Dala Sensori va Klapanlar
              </h3>

              <div className="space-y-2.5">
                {sensors.map((dev, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3.5 bg-slate-950/60 rounded-xl border border-white/10 text-xs">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#00FF9D] animate-pulse" />
                      <div>
                        <p className="font-bold text-slate-100">{dev.name}</p>
                        <p className="text-[10px] text-slate-400">Signal: {dev.signal}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">Batareya: {dev.battery}%</span>
                      <span className="bg-[#00FF9D]/10 text-[#00FF9D] font-extrabold px-3 py-1 rounded-lg border border-[#00FF9D]/30">
                        {dev.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Automation Toggles */}
            <div className="rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 p-5 space-y-4 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              <h3 className="text-sm font-extrabold text-slate-200 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                Avtomatlashtirish va AI Bildirishnomalar
              </h3>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3.5 bg-slate-950/60 rounded-xl border border-white/10">
                  <div>
                    <p className="font-bold text-slate-100">Smart Avto-Sug'orish Rejimi</p>
                    <p className="text-[11px] text-slate-400">Tuproq namligi 50% dan tushganda avtomatik klapanni yoqish</p>
                  </div>
                  <button
                    onClick={() => setAutoIrrigation(!autoIrrigation)}
                    className={`w-12 h-6 flex items-center rounded-full p-1 transition-all ${
                      autoIrrigation ? 'bg-gradient-to-r from-emerald-500 to-teal-400 justify-end' : 'bg-slate-800 justify-start'
                    }`}
                  >
                    <div className="w-4 h-4 rounded-full bg-slate-950 shadow-md" />
                  </button>
                </div>

                <div className="flex items-center justify-between p-3.5 bg-slate-950/60 rounded-xl border border-white/10">
                  <div>
                    <p className="font-bold text-slate-100">Kritik AI Ogohlantirishlar</p>
                    <p className="text-[11px] text-slate-400">Zararkunanda xavfi va sovuq urishi bo'yicha tezkor xabarlar</p>
                  </div>
                  <button
                    onClick={() => setAiAlerts(!aiAlerts)}
                    className={`w-12 h-6 flex items-center rounded-full p-1 transition-all ${
                      aiAlerts ? 'bg-gradient-to-r from-emerald-500 to-teal-400 justify-end' : 'bg-slate-800 justify-start'
                    }`}
                  >
                    <div className="w-4 h-4 rounded-full bg-slate-950 shadow-md" />
                  </button>
                </div>
              </div>
            </div>

            {/* Language Preferences */}
            <div className="rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 p-5 space-y-4 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
              <h3 className="text-sm font-extrabold text-slate-200 flex items-center gap-2">
                <Globe className="w-4 h-4 text-[#00E5FF]" />
                Tizim Tili (Language)
              </h3>

              <div className="grid grid-cols-3 gap-3 text-xs font-bold">
                {[
                  { code: 'uz', label: "O'zbekcha" },
                  { code: 'en', label: "English" },
                  { code: 'ru', label: "Русский" }
                ].map((l) => (
                  <button
                    key={l.code}
                    onClick={() => setLang(l.code)}
                    className={`py-3 rounded-xl border transition-all ${
                      lang === l.code
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 border-emerald-400 shadow-[0_0_15px_rgba(0,255,157,0.3)] font-black'
                        : 'bg-slate-950/60 text-slate-300 border-white/10 hover:border-white/25'
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}

      </main>

      {/* MOBILE-FIRST LIQUID GLASS BOTTOM NAVIGATION BAR (DOCK) */}
      <nav className="fixed bottom-[calc(12px+env(safe-area-inset-bottom))] left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-lg bg-slate-950/80 backdrop-blur-2xl border border-white/15 rounded-3xl p-2 shadow-[0_10px_40px_rgba(0,0,0,0.8)]">
        <div className="flex items-center justify-around">
          
          {[
            { id: 'dashboard', label: 'Boshqaruv', icon: Activity },
            { id: 'fields', label: 'Dalalar', icon: Layers, badge: fields.length },
            { id: 'ai', label: 'AI Maslahat', icon: Sparkles, highlight: true },
            { id: 'settings', label: 'Sozlamalar', icon: Cpu }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex flex-col items-center gap-1 py-1.5 px-3 rounded-2xl transition-all duration-300 ${
                  isActive
                    ? 'text-[#00FF9D]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {/* Active Neon Glow Pill */}
                {isActive && (
                  <div className="absolute inset-0 bg-[#00FF9D]/10 border border-[#00FF9D]/40 rounded-2xl shadow-[0_0_15px_rgba(0,255,157,0.3)] -z-10" />
                )}

                <div className="relative">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-[#00FF9D] drop-shadow-[0_0_8px_rgba(0,255,157,0.8)]' : ''}`} />
                  
                  {tab.badge !== undefined && (
                    <span className="absolute -top-1.5 -right-2.5 bg-emerald-500 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full border border-slate-950">
                      {tab.badge}
                    </span>
                  )}

                  {tab.highlight && !isActive && (
                    <span className="absolute -top-1 -right-1 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400" />
                    </span>
                  )}
                </div>

                <span className={`text-[10px] font-bold ${isActive ? 'text-[#00FF9D]' : 'text-slate-400'}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}

        </div>
      </nav>

    </div>
  );
}